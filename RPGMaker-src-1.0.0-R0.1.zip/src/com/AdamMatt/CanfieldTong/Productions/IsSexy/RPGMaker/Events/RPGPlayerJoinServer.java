/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.AdamMatt.CanfieldTong.Productions.IsSexy.RPGMaker.Events;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class RPGPlayerJoinServer implements Listener {

    @EventHandler
    public void RPGPlayerJoinsServer(PlayerJoinEvent e) {
        //// add event actions later
    }
}
